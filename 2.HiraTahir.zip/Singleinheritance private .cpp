
#include <iostream>
using namespace std;
class B
{
int a;
public:
int b;
void get_ab()
{
cout <<"enter values for a and b";
cin>>a>>b;}
int get_a()
{
return a;
}
void show_a()
{
cout <<"value of a="<<a;
}};
class D: private B
{
int c;
public:
void mult()
{
get_ab();
c=b*get_a();}
void display ()
{
show_a();
cout <<"Value of b="<<b<<endl;
cout <<"value of c="<<c<<endl;
}
};
int main ()
{
D d;
d.mult();
d.display();
return 0;
}