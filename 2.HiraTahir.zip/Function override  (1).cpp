
#include <iostream>
using namespace std;

class Simple {
protected:
    int a;
    int b;

public:
    void in() {
        cout << "enter a and b: ";
        cin >> a >> b;
    }

    void add() {
        cout << "a+b=" << a + b << endl;
    }

    void sub() {
        cout << "a-b=" << a - b << endl;
    }

    void mul() {
        cout << "a*b=" << a * b << endl;
    }

    void div() {
        cout << "a/b=" << a / b << endl;
    }
};

class Complex : public Simple {
public:

    void add() {
    Simple::in();
        if (a <= 0 || b <= 0)
            cout << "invalid values" << endl;
        else
            Simple::add();
    }

    void sub() {
    Simple::in();
        if (a <= 0 || b <= 0)
            cout << "invalid values" << endl;
        else
            Simple::sub();
    }

    void mul() {
    Simple::in();
        if (a <= 0 || b <= 0)
            cout << "invalid values" << endl;
        else
            Simple::mul();
    }

    void div() {
    Simple::in();
        if (a <= 0 || b <= 0)
            cout << "invalid values" << endl;
        else
            Simple::div();
    }
};

int main() {
    Complex obj;
    obj.add();
    obj.in();
    obj.add();
    obj.sub();
    obj.mul();
    obj.div();

    return 0;
}
