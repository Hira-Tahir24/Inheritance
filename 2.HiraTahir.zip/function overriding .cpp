
#include <iostream>
using namespace std;

#include <iostream>
using namespace std;

class Simple {
protected:
    int a;
    int b;

public:
    void in() {
        cout << "enter a and b: ";
        cin >> a >> b;
    }

    void add() {
        cout << "a+b=" << a + b << endl;
    }

    void sub() {
        cout << "a-b=" << a - b << endl;
    }

    void mul() {
        cout << "a*b=" << a * b << endl;
    }

    void div() {
        cout << "a/b=" << a / b << endl;
    }
};

class Complex : public Simple {
public:
    void add() {
        if (a <= 0 || b <= 0)
            cout << "invalid values" << endl;
        else
            Simple::add();
    }

    void sub() {
        if (a <= 0 || b <= 0)
            cout << "invalid values" << endl;
        else
            Simple::sub();
    }

    void mul() {
        if (a <= 0 || b <= 0)
            cout << "invalid values" << endl;
        else
            Simple::mul();
    }

    void div() {
        if (a <= 0 || b <= 0)
            cout << "invalid values" << endl;
        else
            Simple::div();
    }
};

int main() {
    Complex obj;
    
    obj.in();
    obj.add();
    obj.sub();
    obj.mul();
    obj.div();

    return 0;
}
