#include <iostream>
using namespace std;
class Parent
 { public:
 int a;
 protected:
 int b;
 private:
 int c;
 public:
  void get_c()
 { cout <<"enter c";
 cin>>c;}
 void show_c()
 { cout <<"Value of c="<<c<<endl;}
 };
 class Child: private Parent 
 {public:
 void in()
 
 { 
 cout <<"enter a and b";
 cin>>a>>b;
 get_c();
 }
 void show ()
 { 
 cout <<"value of a="<<a<<endl;
 cout <<"Value of b="<<b <<endl;
 show_c();
 }
 };
 int main ()
 { Child obj;
 
 obj.in();
 obj.show();
 }