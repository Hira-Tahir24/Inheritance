
#include <iostream>
using namespace std;
class B
{
int a;
public:
int b;
void get_ab()
{
cout <<"enter value of a and b";
cin >>a>>b;}
int get_a()
{
return a;
}
void show_a()
{
cout <<"value of a="<<a;
}};
class D: public B
{
int c;
public:
void mult()
{
c=b*get_a();}
void display ()
{
cout <<"Value of b="<<b<<endl;
cout <<"value of c="<<c<<endl;
}
};
int main ()
{
D d;
d.get_ab();
d.get_a();
d.show_a();
d.mult();
d.display();
d.b=29;

d.mult();
d.display();
return 0;
}