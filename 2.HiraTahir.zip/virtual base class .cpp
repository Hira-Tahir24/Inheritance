
#include <iostream>
using namespace std;
class Student 
{
protected:
int roll_no;
public:
void set_no(int x)
{
roll_no=x;
}
void get_no()
{
cout <<"Roll number="<<roll_no<<endl;
}};
class Test: virtual public Student 
{ protected:
float part1;
float part2;
public:
void set_marks(float a, float b)
{
part1=a;
part2=b;
}
public:
void get_marks()
{
cout <<"Marks obtained="<<endl;
cout <<"Part 1="<<part1<<endl;
cout <<"Part 2="<<part2<<endl;
}};
class Sports:  virtual public Student 
{
protected:
float score;
public:
void set_score(float s)
{
score=s;
}
void get_score()
{
cout <<"Sports wt="<<score <<endl;
}};
class Result: public Test, public Sports 
{
float total;
public:
void display ()
{
get_no();
get_marks();
get_score();
total=part1+part2+score;
cout <<"Total score="<<total <<endl;
}};
int main ()
{
Result s1;
s1.set_no(29);
s1.set_marks(75.0,89.5);
s1.set_score(63);
s1.display();
}