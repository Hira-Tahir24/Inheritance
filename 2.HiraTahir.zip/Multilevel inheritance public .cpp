
#include <iostream>
using namespace std;
class Student 
{ protected:
int roll_no;
public:
void setnumber(int a)
{
roll_no=a;}
void getnumber()
{ cout <<"Roll number="<<roll_no<<endl;
}};
class Test: public Student 
{
protected:
float sub1;
float sub2;
public:
void setmarks(float x, float y)
{
sub1=x;
sub2=y;}
void getmarks()
{
cout <<"Marks in Subject 1="<<sub1<<endl;
cout <<"Marks in Subject 2="<<sub2<<endl;}
};
class Result: public Test 
{private:
float total;
public:
void display()
{ total=sub1 + sub2;
getnumber();
getmarks ();
cout <<" Total="<<total<<endl;
}};
int main ()
{
Result R;
R.setnumber(29);
R.setmarks(75.0,95.5);
R.display();
}