
#include <iostream>
using namespace std;
class M
{
protected:
int m;
public:
void set_m(int x)
{
m=x;}
};
class N
{
protected:
int n;
public:
void set_n(int y)
{
n=y;}
};
class P: public M, public N
{
public:

void display ()
{
cout <<"value of m="<<m<<endl;
cout <<"Value of n="<<n<<endl;
cout <<"Value of m*n="<<m*n<<endl;
}
};
int main ()
{
P p;
p.set_m(10);
p.set_n(9);
p.display();
}
