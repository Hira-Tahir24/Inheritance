#include <iostream>
using namespace std;
class Parent
 { public:
 int a;
 protected:
 int b;
 private:
 int c;
 
 };
 class Child: protected Parent 
 {public:
 void in()
 
 { 
 cout <<"enter a and b";
 cin>>a>>b;
 
 }
 void show ()
 { 
 cout <<"value of a="<<a<<endl;
 cout <<"Value of b="<<b <<endl;
 
 }
 };
 int main ()
 { Child obj;
 
 obj.in();
 obj.show();
 }